<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>

    <!-- menu -->
    
    <nav class="navbar navbar-expand-lg" style="background-color: #a3a3a3;">
        <div class="mx-5 container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="assets/img/logo.png" alt="logo" width="100" height="auto">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            
                            Livros
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="registar-livros.php">Registar</a></li>
                            <li><a class="dropdown-item" href="editar-livros.php">Editar</a></li>
                            <li><a class="dropdown-item" href="listar-livros.php">Listar</a></li>
                        </ul>
                    </li>      
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Sócios
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="registar-socios.php">Registar</a></li>
                            <li><a class="dropdown-item" href="editar-socios.php">Editar</a></li>
                            <li><a class="dropdown-item" href="listar-socios.php">Listar</a></li>
                        </ul>
                    </li>      
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Empréstimos
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="registar-emprestimos.php">Registar</a></li>
                            <li><a class="dropdown-item" href="editar-emprestimos.php">Editar</a></li>
                            <li><a class="dropdown-item" href="listar-emprestimos.php">Listar</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle bg-primary link-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Colaboradores
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="registar-colaboradores.php">Registar</a></li>
                            <li><a class="dropdown-item bg-primary link-light" href="editar-colaboradores.php"><strong>Editar</strong></a></li>
                            <li><a class="dropdown-item" href="listar-colaboradores.php">Listar</a></li>
                        </ul>
                    </li>              
                </ul>
            </div>
        </div>
    </nav>

    <!-- edit staff -->
    <div class="container">
        <div class="row">
            
            <div class="col-12 my-4">
                <h4>Editar Colaboradores</h4>
            </div>
            
            <div class="col-6 my-3">
                <div class="mb-3">
                    <label for="selectColaborador" class="form-label">Selecionar Colaborador:</label>
                    <select class="form-select" aria-label="Default select example" id="selectColaborador" onchange="getInfoColaborador(this.value)">

                    </select>
                </div>
                <div class="mb-3">
                    <label for="idFunc" class="form-label">ID:</label>
                    <input type="text" class="form-control" id="idFuncEdit" disabled>
                </div>
                <div class="mb-3">
                    <label for="nomeFuncEdit" class="form-label">Nome:</label>
                    <input type="text" class="form-control" id="nomeFuncEdit">
                </div>
                <div class="mb-3">
                    <label for="moradaFuncEdit" class="form-label">Morada:</label>
                    <input type="text" class="form-control" id="moradaFuncEdit">
                </div>
                <div class="mb-3">
                    <label for="telefoneFuncEdit" class="form-label">Telefone:</label>
                    <input type="text" class="form-control" id="telefoneFuncEdit">
                </div>
                <div class="mb-3">
                    <label for="emailFuncEdit" class="form-label">Email:</label>
                    <input type="text" class="form-control" id="emailFuncEdit">
                </div>
                <div class="mb-3">
                    <label for="numFuncEdit" class="form-label">Nº de Funcionário:</label>
                    <input type="text" class="form-control" id="numFuncEdit">
                </div>
                <div class="col-3 mb-3">
                    <label for="numCCEdit" class="form-label">Nº de Cartão de Cidadão:</label>
                    <input type="text" class="form-control" id="numCcEdit" maxlength="12" disabled>
                </div>
                <div class="col-3 mb-3">
                    <button type="button" class="btn btn-primary" onclick="toggleNumCC()">Revelar/bloquear</button>
                </div>

                <div class="mb-3">
                    <label for="dataNascFuncEdit" class="form-label">Data de Nascimento:</label>
                    <input type="date" class="form-control" id="dataNascFuncEdit">
                </div>
                <div class="mb-3">
                    <label for="tipoFuncEdit" class="form-label">Tipo:</label>
                    <select class="form-select" id="tipoFuncEdit" onclick="getTiposFunc()">
                    </select>
                </div>

                <button type="button" class="btn btn-primary" id="btnGuardarColaborador">Guardar</button>
            </div>
        </div>
    </div>

</body>
</html>