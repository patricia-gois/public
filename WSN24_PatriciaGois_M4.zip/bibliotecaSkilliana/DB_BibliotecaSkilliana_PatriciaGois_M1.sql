-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- SO do servidor:               Win64
-- HeidiSQL Versão:              12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- A despejar estrutura da base de dados para libskilliana_patriciagois_n24
DROP DATABASE IF EXISTS `libskilliana_patriciagois_n24`;
CREATE DATABASE IF NOT EXISTS `libskilliana_patriciagois_n24` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `libskilliana_patriciagois_n24`;

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.autores
DROP TABLE IF EXISTS `autores`;
CREATE TABLE IF NOT EXISTS `autores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `infoextra` text DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `instragam` varchar(50) DEFAULT NULL,
  `x` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.autores: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.emprestimo
DROP TABLE IF EXISTS `emprestimo`;
CREATE TABLE IF NOT EXISTS `emprestimo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_registo` date DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `id_utilizador` int(11) DEFAULT NULL,
  `id_socio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__utilizador` (`id_utilizador`),
  KEY `FK__socio` (`id_socio`),
  CONSTRAINT `FK__socio` FOREIGN KEY (`id_socio`) REFERENCES `socio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK__utilizador` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.emprestimo: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.estante
DROP TABLE IF EXISTS `estante`;
CREATE TABLE IF NOT EXISTS `estante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) NOT NULL DEFAULT '0',
  `id_seccao` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `FK__seccao` (`id_seccao`),
  CONSTRAINT `FK__seccao` FOREIGN KEY (`id_seccao`) REFERENCES `seccao` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.estante: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livros
DROP TABLE IF EXISTS `livros`;
CREATE TABLE IF NOT EXISTS `livros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) DEFAULT NULL,
  `isbn` varchar(200) DEFAULT NULL,
  `sinopse` text DEFAULT NULL,
  `qtd` int(11) DEFAULT NULL,
  `datalanc` date DEFAULT NULL,
  `edicao` varchar(200) DEFAULT NULL,
  `editora` varchar(200) DEFAULT NULL,
  `idioma` varchar(200) DEFAULT NULL,
  `qtdpaginas` int(11) DEFAULT NULL,
  `estado` binary(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livros: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livros_autores
DROP TABLE IF EXISTS `livros_autores`;
CREATE TABLE IF NOT EXISTS `livros_autores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_livro` int(11) DEFAULT NULL,
  `id_autor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__livros` (`id_livro`),
  KEY `id_autor` (`id_autor`),
  CONSTRAINT `FK__livros` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_autor` FOREIGN KEY (`id_autor`) REFERENCES `autores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livros_autores: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livros_tipo
DROP TABLE IF EXISTS `livros_tipo`;
CREATE TABLE IF NOT EXISTS `livros_tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo` int(11) NOT NULL DEFAULT 0,
  `id_livro` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `FK_livros_tipo_tipo_livro` (`id_tipo`),
  KEY `FK_livros_tipo_livros` (`id_livro`),
  CONSTRAINT `FK_livros_tipo_livros` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_livros_tipo_tipo_livro` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_livro` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livros_tipo: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livro_emprestimo
DROP TABLE IF EXISTS `livro_emprestimo`;
CREATE TABLE IF NOT EXISTS `livro_emprestimo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprestimo` int(11) NOT NULL DEFAULT 0,
  `id_livro` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `FK__emprestimo` (`id_emprestimo`),
  KEY `FK_livro_emprestimo_livros` (`id_livro`),
  CONSTRAINT `FK__emprestimo` FOREIGN KEY (`id_emprestimo`) REFERENCES `emprestimo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_livro_emprestimo_livros` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livro_emprestimo: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livro_estante
DROP TABLE IF EXISTS `livro_estante`;
CREATE TABLE IF NOT EXISTS `livro_estante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_livro` int(11) DEFAULT NULL,
  `id_estante` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_livro_estante_livros` (`id_livro`),
  KEY `FK_livro_estante_estante` (`id_estante`),
  CONSTRAINT `FK_livro_estante_estante` FOREIGN KEY (`id_estante`) REFERENCES `estante` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_livro_estante_livros` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livro_estante: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.seccao
DROP TABLE IF EXISTS `seccao`;
CREATE TABLE IF NOT EXISTS `seccao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.seccao: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.socio
DROP TABLE IF EXISTS `socio`;
CREATE TABLE IF NOT EXISTS `socio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL DEFAULT '0',
  `cc` varchar(50) NOT NULL DEFAULT '0',
  `numsocio` varchar(50) NOT NULL DEFAULT '0',
  `morada` varchar(50) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '0',
  `telefone` varchar(50) NOT NULL DEFAULT '0',
  `datanasc` year(4) NOT NULL DEFAULT 0000,
  `estado` binary(50) NOT NULL DEFAULT '0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.socio: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.tipo_livro
DROP TABLE IF EXISTS `tipo_livro`;
CREATE TABLE IF NOT EXISTS `tipo_livro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.tipo_livro: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.tipo_utilizador
DROP TABLE IF EXISTS `tipo_utilizador`;
CREATE TABLE IF NOT EXISTS `tipo_utilizador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.tipo_utilizador: ~0 rows (aproximadamente)

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.utilizador
DROP TABLE IF EXISTS `utilizador`;
CREATE TABLE IF NOT EXISTS `utilizador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) DEFAULT NULL,
  `morada` varchar(200) DEFAULT NULL,
  `telefone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `numfunc` varchar(200) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `id_tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__tipo_utilizador` (`id_tipo`),
  CONSTRAINT `FK__tipo_utilizador` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_utilizador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.utilizador: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
