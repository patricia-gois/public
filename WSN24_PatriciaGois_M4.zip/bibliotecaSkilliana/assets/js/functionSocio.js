function registaSocio(){

    let dados = new FormData();
    dados.append ("nome", $('#nomeSocio').val());
    dados.append ("cc", $('#ccSocio').val());
    dados.append ("numsocio", $('#numSocio').val());
    dados.append ("morada", $('#moradaSocio').val());
    dados.append ("email", $('#emailSocio').val());
    dados.append ("telefone", $('#telefoneSocio').val());
    dados.append ("datanasc", $('#dataNascSocio').val());
    dados.append ("estado", $('#estadoSocio').val());
    dados.append ('op', 1);

    $.ajax({
    url: "assets/controller/controllerSocio.php",
    method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    .done(function( msg ) {
        alerta("Success", msg, "success"); // Use SweetAlert instead of alert
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

////////////////////////////////////////////////////////////////

//Sweetalert
function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,
    });
  }
  
$(function() {

});

