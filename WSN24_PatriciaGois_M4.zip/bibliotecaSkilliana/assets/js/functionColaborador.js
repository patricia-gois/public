
document.addEventListener('DOMContentLoaded', function() {
    // Get today's date
    const today = new Date();
    
    // Calculate the date 18 years ago
    const minDate = new Date();
    minDate.setFullYear(today.getFullYear() - 18);
    
    // Format the date as YYYY-MM-DD
    const yyyy = minDate.getFullYear();
    const mm = String(minDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const dd = String(minDate.getDate()).padStart(2, '0');
    const formattedMinDate = `${yyyy}-${mm}-${dd}`;
    
    // Set the min attribute of the date input
    document.getElementById('dataNascFunc').min = formattedMinDate;
});

    function registaColaborador() {
        let dados = new FormData();
        dados.append("nome", $('#nomeFunc').val());
        dados.append("morada", $('#moradaFunc').val());
        dados.append("telefone", $('#telefoneFunc').val());
        dados.append("email", $('#emailFunc').val());
        dados.append("numfunc", $('#numFunc').val());
        dados.append("numcc", $('#numCC').val()); //new field
        dados.append("datanasc", $('#dataNascFunc').val());
        dados.append("id_tipo", $('#tipoFunc').val());
        dados.append('op', 1);
    
        $.ajax({
            url: "assets/controller/controllerColaboradores.php",
            method: "POST",
            data: dados,
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false
        })
        .done(function(response) {
            // Check the success flag in the response
            if (response.success) {
                alerta("Success", response.message, "success"); // Success alert
            } else {
                alerta("Error", response.message, "error"); // Error alert
            }
        })
        .fail(function(jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
    }
    

function getTiposFunc(){
    let dados = new FormData();
    dados.append('op', 7);
  
  
    $.ajax({
      url: "assets/controller/controllerColaboradores.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData:false,
    })
    
    .done(function( msg ) {
     $('#tipoFunc').html(msg);     
     $('#tipoFuncEdit').html(msg);     
  
    })
    
    .fail(function( jqXHR, textStatus ) {
      alert( "Request failed: " + textStatus );
    });
  }

  function getColaborador(){
    let dados = new FormData();
    dados.append('op', 8);
  
  
    $.ajax({
      url: "assets/controller/controllerColaboradores.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData:false,
    })
    
    .done(function( msg ) {
     $('#selectColaborador').html(msg);       
    })
    
    .fail(function( jqXHR, textStatus ) {
      alert( "Request failed: " + textStatus );
    });
  }


function listaColaboradores(){

    let dados = new FormData();
    dados.append ('op', 2);
   
    $.ajax({
    url: "assets/controller/controllerColaboradores.php",
    method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    .done(function( msg ) {
        $('#listaColaboradores').html(msg);
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getInfoColaborador(id) {
    let dados = new FormData();
    dados.append('id', id);
    dados.append('op', 3);  // fetches the user info based on the user ID

    $.ajax({
        url: "assets/controller/controllerColaboradores.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function(msg) {
        let obj = JSON.parse(msg);
        $('#nomeFuncEdit').val(obj.nome);
        $('#moradaFuncEdit').val(obj.morada);
        $('#telefoneFuncEdit').val(obj.telefone);
        $('#emailFuncEdit').val(obj.email);
        $('#numFuncEdit').val(obj.numfunc);
        $('#numCcEdit').val(obj.numcc); //new field
        $('#dataNascFuncEdit').val(obj.datanasc);
        $('#tipoFuncEdit').val(obj.id_tipo);

        // Set up the button to call the save function
        $('#btnGuardarColaborador').attr("onclick", 'guardaEditColaborador('+id+')');
    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function toggleNumCC() {
    const numCCInput = document.getElementById('numCcEdit');
    if (numCCInput.disabled) {
        numCCInput.disabled = false;  // Enable the input field
    } else {
        numCCInput.disabled = true;   // Disable the input field
    }
}


function removerColaborador(id){

    let dados = new FormData();
    dados.append ('id', id);
    dados.append ('op', 6);
   
    $.ajax({
    url: "assets/controller/controllerColaboradores.php",
    method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    .done(function( msg ) {
        alerta("Success", msg, "success"); // Use SweetAlert instead of alert
        listaColaboradores();
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}




function guardaEditColaborador(id) {
    let dados = new FormData();
    dados.append("id", id); 
    dados.append("nome", $('#nomeFuncEdit').val());
    dados.append("morada", $('#moradaFuncEdit').val());
    dados.append("telefone", $('#telefoneFuncEdit').val());
    dados.append("email", $('#emailFuncEdit').val());
    dados.append("numfunc", $('#numFuncEdit').val());
    dados.append("numcc", $('#numCcEdit').val()); //new field
    dados.append("datanasc", $('#dataNascFuncEdit').val());
    dados.append("id_tipo", $('#tipoFuncEdit').val());
    
    dados.append('op', 5);  

    $.ajax({
        url: "assets/controller/controllerColaboradores.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function(msg) {
        getTiposFunc();
        alerta("Success", msg, "success"); 
        listaColaboradores(); 
    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

  function contagemColaboradores(){

    let dados = new FormData();
    dados.append ('op', 8);
   
    $.ajax({
    url: "assets/controller/controllerColaboradores.php",
    method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    .done(function( msg ) {
        $('#totalColaboradores').html(msg);
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

////////////////////////////////////////////////////////////////

//Sweetalert
function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,
    });
  }

  //DataTables
  new DataTable('#listagemColaboradores', {
    layout: {
        topStart: 'search',
        topEnd: null
    }
  });

$(function() {
    getTiposFunc();
    listaColaboradores();
    getColaborador();
    //contagemColaboradores();
});

