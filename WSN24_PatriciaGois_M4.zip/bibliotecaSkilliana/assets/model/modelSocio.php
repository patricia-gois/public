<?php

require_once 'connection.php';

class Socio {

    function registaSocio($nome, $cc, $numsocio, $morada, $email, $telefone, $datanasc, $estado ) {

        global $conn;
        $msg = "";
        $flag = true;

        // Prepare statement
        $stmt = $conn->prepare("INSERT INTO socio (nome, cc, numsocio, morada, email, telefone, datanasc, ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssii", $nome, $cc, $numsocio, $morada, $email, $telefone, $datanasc, $estado);

        // Execute statement
        if ($stmt->execute()) {
            $msg = "Registo efetuado com sucesso.";
        } else {
            $flag = false;
            $msg = $stmt->error; //send error alert to technical system
        }

        $msg = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        $stmt->close();

        return $msg;
        $conn->close();

    }
    
}

?>