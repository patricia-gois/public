<?php






?>

function carregarColaboradores() {
    let dados = new FormData();
    dados.append('op', 6); // Um código de operação para listar colaboradores

    $.ajax({
        url: "assets/controller/controllerColaboradores.php",
        method: "POST",
        data: dados,
        dataType: "json",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function(resposta) {
        let select = $('#colaboradorSelect');
        select.empty(); // Limpa opções anteriores
        select.append("<option value=''>Selecione um colaborador</option>");

        if (resposta.success) {
            resposta.colaboradores.forEach(function(colaborador) {
                select.append(`<option value="${colaborador.id}">${colaborador.nome}</option>`);
            });
        } else {
            alert(resposta.message);
        }
    })
    .fail(function(jqXHR, textStatus) {
        alert("Erro ao carregar colaboradores: " + textStatus);
    });
}
