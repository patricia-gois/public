<?php
require_once '../model/modelEmprestimo.php';

$emprestimo = new Emprestimo();

if($_POST['op'] == 1){
    $resposta = $emprestimo -> registaEmprestimo($_POST['id_cliente'], $_POST['id_voo'], $_POST['qtd_passageiros'], $_POST['valor_total']);
    echo($resposta);
}else if($_POST['op'] == 2){
    $resposta = $emprestimo -> getSelectSocio($_POST['id'], $_POST['nome']);
    echo($resposta);
}else if($_POST['op'] == 3){
    $resposta = $emprestimo -> listaEmprestimos();
    echo($resposta);
}else if($_POST['op'] == 4){
    $res = $emprestimo -> removerEmprestimo($_POST['id']);
    echo($resposta);
}else if($_POST['op'] == 5){
    $resposta = $emprestimo -> getSelectLivro($_POST['id'], $_POST['titulo']);
    echo($resposta);
}

?>