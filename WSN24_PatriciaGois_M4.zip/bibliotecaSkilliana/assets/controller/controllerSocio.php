<?php
require_once '../model/modelSocio.php';

$socio = new Socio();

if($_POST['op'] == 1){
    $resposta = $socio -> registaSocio(
        $_POST['nome'], 
        $_POST['cc'], 
        $_POST['numsocio'], 
        $_POST['morada'], 
        $_POST['email'], 
        $_POST['telefone'], 
        $_POST['datanasc'],
        $_POST['estado']);
    echo($resposta);
}


?>