<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>

<body>
<!-- menu -->
<nav class="navbar navbar-expand-lg" style="background-color: #a3a3a3;">
        <div class="mx-5 container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="assets/img/logo.png" alt="logo" width="100" height="auto">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        
                        Livros
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-livros.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-livros.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-livros.php">Listar</a></li>
                    </ul>
                </li>      
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Sócios
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-socios.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-socios.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-socios.php">Listar</a></li>
                    </ul>
                </li>      
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Empréstimos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-emprestimos.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-emprestimos.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-emprestimos.php">Listar</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle bg-primary link-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Colaboradores
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item bg-primary link-light" href="registar-colaboradores.php"><strong>Registar</strong></a></li>
                        <li><a class="dropdown-item" href="editar-colaboradores.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-colaboradores.php">Listar</a></li>
                    </ul>
                </li>              
            </ul>
          </div>
        </div>
      </nav>


<!-- Register users  -->
<div class="container">
    <div class="row">
        <div class="col-12 my-4">
            <h4>Registar Colaborador</h4>
        </div>
        
        <div class="col-6">
            <div class="mb-3">
                <label for="nomeFunc" class="form-label">Nome:</label>
                <input type="text" class="form-control" id="nomeFunc" required>
            </div>
            <div class="mb-3">
                <label for="moradaFunc" class="form-label">Morada:</label>
                <input type="text" class="form-control" id="moradaFunc" required>
            </div>
            <div class="mb-3">
                <label for="telefoneFunc" class="form-label">Telefone:</label>
                <input type="tel" class="form-control" id="telefoneFunc" required>
            </div>
            <div class="mb-3">
                <label for="emailFunc" class="form-label">Email:</label>
                <input type="email" class="form-control" id="emailFunc" required>
            </div>
            <div class="mb-3">
                <label for="numFunc" class="form-label">Nº de Funcionário:</label>
                <input type="text" class="form-control" id="numFunc" required>
            </div>
            <div class="mb-3">
                <label for="numCC" class="form-label">Nº de Cartão de Cidadão:</label>
                <input type="text" class="form-control" id="numCC" maxlength="12">
            </div>

            <div class="mb-3">
                <label for="dataNascFunc" class="form-label">Data de Nascimento:</label>
                <input type="date" class="form-control" id="dataNascFunc" required>
            </div>

            <div class="mb-3">
                    <label for="tipoFunc" class="form-label">Tipo de Funcionário:</label>
                    <select class="form-select" aria-label="Default select example" id="tipoFunc" required>
                    </select>
            </div>

            <button type="button" class="btn btn-dark" onclick="registaColaborador()">Guardar</button>
        </div>
    </div>
</div>


</body>
</html>