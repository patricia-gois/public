<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>

    <!-- includes the menu -->
    <nav class="navbar navbar-expand-lg" style="background-color: #a3a3a3;">
        <div class="mx-5 container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="assets/img/logo.png" alt="logo" width="100" height="auto">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Livros
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-livros.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-livros.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-livros.php">Listar</a></li>
                    </ul>
                </li>     
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Colaboradores
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-colaboradores.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-colaboradores.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-colaboradores.php">Listar</a></li>
                    </ul>
                </li>    
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Sócios
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-socios.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-socios.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-socios.php">Listar</a></li>
                    </ul>
                </li>      
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Empréstimos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-emprestimos.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-emprestimos.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-emprestimos.php">Listar</a></li>
                    </ul>
                </li>            
            </ul>
          </div>
        </div>
    </nav>

    <!-- edit book -->
    <div class="container">
        <div class="row">
            
        <div class="col-12 my-4">
            <h4>Editar Livros</h4>
        </div>
        <div class="col-6 my-3">

        <div class="mb-3">
            <label for="selectLivro" class="form-label">Selecionar Livro:</label>
            <select class="form-select" aria-label="Default select example" id="selectLivro" onchange="getInfoLivro(this.value)"></select>

        </div>

                        <div class="mb-3">
                            <label for="tituloLivro" class="form-label">Título:</label>
                            <input type="text" class="form-control" id="tituloLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="isbnLivro" class="form-label">ISBN:</label>
                            <input type="text" class="form-control" id="isbnLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="sinopseLivro" class="form-label">Sinopse:</label>
                            <input type="text" class="form-control" id="sinopseLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="qtdLivro" class="form-label">Quantidade:</label>
                            <input type="number" class="form-control" id="qtdLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="dataLancLivro" class="form-label">Data de Lançamento:</label>
                            <input type="date" class="form-control" id="dataLancLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="edicaoLivro" class="form-label">Edição:</label>
                            <input type="text" class="form-control" id="edicaoLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="editoraLivro" class="form-label">Editora:</label>
                            <input type="text" class="form-control" id="editoraLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="idiomaLivro" class="form-label">Idioma:</label>
                            <input type="text" class="form-control" id="idiomaLivroEdit">
                        </div>
                        <div class="mb-3">
                            <label for="qtdPaginasLivro" class="form-label">Nº de Páginas:</label>
                            <input type="number" class="form-control" id="qtdPaginasLivroEdit">
                        </div>

                        <div class="mb-3">
                            <label for="localSelect" class="form-label">Estado:</label>
                            <select class="form-select" aria-label="Default select example" id="estadoLivroEdit">
                                <option value="-1">Selecione uma opção</option>
                                <option value="0">Esgotado</option>
                                <option value="1">Disponível</option>
                            </select>
                            </select>
                        </div>
        
                <button type="button" class="btn btn-primary" id="btnGuardarLivro">Guardar</button>
    </div>

    </div>
</div>


   
</div>

</body>
</html>