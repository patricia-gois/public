<!DOCTYPE html>
<html lang="en">
    <?php include "head.php"; ?>
<body>

    <!-- menu -->
    <nav class="navbar navbar-expand-lg" style="background-color: #a3a3a3;">
        <div class="mx-5 container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="assets/img/logo.png" alt="logo" width="100" height="auto">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        
                        Livros
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-livros.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-livros.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-livros.php">Listar</a></li>
                    </ul>
                </li>      
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Sócios
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-socios.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-socios.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-socios.php">Listar</a></li>
                    </ul>
                </li>      
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Empréstimos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-emprestimos.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-emprestimos.php">Editar</a></li>
                        <li><a class="dropdown-item" href="listar-emprestimos.php">Listar</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle bg-primary link-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Colaboradores
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="registar-colaboradores.php">Registar</a></li>
                        <li><a class="dropdown-item" href="editar-colaboradores.php">Editar</a></li>
                        <li><a class="dropdown-item bg-primary link-light" href="listar-colaboradores.php"><strong>Listar</strong></a></li>
                    </ul>
                </li>              
            </ul>
          </div>
        </div>
      </nav>

    
    <!-- Staff list -->

    <div class="container mt-4 mb-3">
        <div class="row">
            <div class="col-12 mt-4">
                <h3>Lista de Colaboradores</h3>
            </div>
            <table class="table table-striped" id="listagemColaboradores">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Morada</th>
                        <th scope="col">Telefone</th>
                        <th scope="col">Email</th>
                        <th scope="col">Nº Funcionário</th>
                        <th scope="col">Nº Cartão Cidadão</th>
                        <th scope="col">Data de Nascimento</th>
                        <th scope="col">Tipo de Funcionário</th>
                        <th scope="col">Remover?</th>
                    </tr>
                </thead>
                <tbody id="listaColaboradores"></tbody>
            </table>
        </div>
    </div>

</body>
</html>