<!-- jQuery -->
<script src="assets/js/jquery.js"></script>

<!-- datatable -->
<script src="assets/js/datatable.js"></script>

<!-- sweetalert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<!-- custom scripts -->
<script src="assets/js/functionLogin.js"></script>
<script src="assets/js/functionLivro.js"></script>
<script src="assets/js/functionSocio.js"></script>
<script src="assets/js/functionColaborador.js"></script>
<script src="assets/js/functionEmprestimo.js"></script>


