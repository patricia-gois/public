-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- SO do servidor:               Win64
-- HeidiSQL Versão:              12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- A despejar estrutura da base de dados para libskilliana_patriciagois_n24
DROP DATABASE IF EXISTS `libskilliana_patriciagois_n24`;
CREATE DATABASE IF NOT EXISTS `libskilliana_patriciagois_n24` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `libskilliana_patriciagois_n24`;

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.autor
DROP TABLE IF EXISTS `autor`;
CREATE TABLE IF NOT EXISTS `autor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `dataNasc` date DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `redeSocial_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.autor: ~5 rows (aproximadamente)
INSERT INTO `autor` (`id`, `nome`, `dataNasc`, `bio`, `redeSocial_id`) VALUES
	(1, 'Autor 1', '1990-01-01', 'Bio do autor 1', 1),
	(2, 'Autor 2', '1985-06-15', 'Bio do autor 2', 2),
	(3, 'Autor 3', '1970-03-20', 'Bio do autor 3', 3),
	(4, 'Autor 4', '1995-09-10', 'Bio do autor 4', 4),
	(5, 'Autor 5', '1980-11-25', 'Bio do autor 5', 5);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.colaborador
DROP TABLE IF EXISTS `colaborador`;
CREATE TABLE IF NOT EXISTS `colaborador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `morada` varchar(255) DEFAULT NULL,
  `tel` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `dataNasc` date DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipoCol_id` (`tipo_id`) USING BTREE,
  CONSTRAINT `FK_colaborador_tipocol` FOREIGN KEY (`tipo_id`) REFERENCES `tipocol` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.colaborador: ~5 rows (aproximadamente)
INSERT INTO `colaborador` (`id`, `nome`, `morada`, `tel`, `email`, `num`, `dataNasc`, `tipo_id`) VALUES
	(1, 'Nome 1', 'morada1', 999999999, 'email1', 1, '2002-09-25', 1),
	(2, 'Nome 2', 'morada 2', 345789654, 'email2', 2, '2020-09-25', 3),
	(3, 'nome 3', 'morada 3', 234566789, 'email3', 3, '1988-09-25', 2),
	(4, 'nome 4', 'mroada 4', 345678907, 'email4', 4, '1997-09-25', 1),
	(5, 'nome 5', 'morada 5', 234567890, 'email5', 5, '1994-09-25', 3);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.emprestimo
DROP TABLE IF EXISTS `emprestimo`;
CREATE TABLE IF NOT EXISTS `emprestimo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dataRegisto` date DEFAULT NULL,
  `dataPrevDev` date DEFAULT NULL,
  `livro_id` int(11) DEFAULT NULL,
  `socio_cc` int(11) DEFAULT NULL,
  `colaborador_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `livro_id` (`livro_id`),
  KEY `colaborador_id` (`colaborador_id`),
  KEY `socio_cc` (`socio_cc`),
  CONSTRAINT `colaborador_id` FOREIGN KEY (`colaborador_id`) REFERENCES `colaborador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `livro_id` FOREIGN KEY (`livro_id`) REFERENCES `livro` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `socio_cc` FOREIGN KEY (`socio_cc`) REFERENCES `socio` (`cc`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.emprestimo: ~1 rows (aproximadamente)
INSERT INTO `emprestimo` (`id`, `dataRegisto`, `dataPrevDev`, `livro_id`, `socio_cc`, `colaborador_id`) VALUES
	(1, '2024-09-25', '2025-09-25', 1, NULL, 4);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.estadosocio
DROP TABLE IF EXISTS `estadosocio`;
CREATE TABLE IF NOT EXISTS `estadosocio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.estadosocio: ~2 rows (aproximadamente)
INSERT INTO `estadosocio` (`id`, `descr`) VALUES
	(1, 'ativo'),
	(2, 'inativo');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.estante
DROP TABLE IF EXISTS `estante`;
CREATE TABLE IF NOT EXISTS `estante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.estante: ~5 rows (aproximadamente)
INSERT INTO `estante` (`id`, `descr`) VALUES
	(1, '1'),
	(2, '2'),
	(3, '3'),
	(4, '4'),
	(5, '5');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.genero
DROP TABLE IF EXISTS `genero`;
CREATE TABLE IF NOT EXISTS `genero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.genero: ~5 rows (aproximadamente)
INSERT INTO `genero` (`id`, `descr`) VALUES
	(1, 'romance'),
	(2, 'comedia'),
	(3, 'horror'),
	(4, 'cientifico'),
	(5, 'zombies');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livro
DROP TABLE IF EXISTS `livro`;
CREATE TABLE IF NOT EXISTS `livro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) DEFAULT NULL,
  `dataLanc` date DEFAULT NULL,
  `autor_id` int(11) DEFAULT NULL,
  `sinopse` text DEFAULT NULL,
  `edicao` int(11) DEFAULT NULL,
  `editora` varchar(255) DEFAULT NULL,
  `idioma` varchar(255) DEFAULT NULL,
  `isbn` int(11) DEFAULT NULL,
  `numPag` int(11) DEFAULT NULL,
  `generos` int(11) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generos` (`generos`),
  KEY `autor_id` (`autor_id`),
  CONSTRAINT `autor_id` FOREIGN KEY (`autor_id`) REFERENCES `autor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `generos` FOREIGN KEY (`generos`) REFERENCES `livrogeneros` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livro: ~2 rows (aproximadamente)
INSERT INTO `livro` (`id`, `titulo`, `dataLanc`, `autor_id`, `sinopse`, `edicao`, `editora`, `idioma`, `isbn`, `numPag`, `generos`, `estado`) VALUES
	(1, 'livro 1', '2024-09-25', 2, 'sinopse 1', 2, 'editora1', 'pt', 1234, 100, 2, 'indisponivel'),
	(2, 'livro2', '2024-09-25', 4, 'sinopse 2', 1, 'editora 2', 'pt', 1235, 102, 3, 'disponivel');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livroestanteseccao
DROP TABLE IF EXISTS `livroestanteseccao`;
CREATE TABLE IF NOT EXISTS `livroestanteseccao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `livrolocal_id` int(11) DEFAULT NULL,
  `estante_id` int(11) DEFAULT NULL,
  `seccao_id` int(11) DEFAULT NULL,
  `qtd` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estante_id` (`estante_id`),
  KEY `seccao_id` (`seccao_id`),
  KEY `livrolocal_id` (`livrolocal_id`),
  CONSTRAINT `estante_id` FOREIGN KEY (`estante_id`) REFERENCES `estante` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `livrolocal_id` FOREIGN KEY (`livrolocal_id`) REFERENCES `livro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `seccao_id` FOREIGN KEY (`seccao_id`) REFERENCES `seccao` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livroestanteseccao: ~1 rows (aproximadamente)
INSERT INTO `livroestanteseccao` (`id`, `livrolocal_id`, `estante_id`, `seccao_id`, `qtd`) VALUES
	(1, 1, NULL, 2, 3);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.livrogeneros
DROP TABLE IF EXISTS `livrogeneros`;
CREATE TABLE IF NOT EXISTS `livrogeneros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `livroo_id` int(11) DEFAULT NULL,
  `genero_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `genero_id` (`genero_id`),
  KEY `livroo_id` (`livroo_id`),
  CONSTRAINT `genero_id` FOREIGN KEY (`genero_id`) REFERENCES `genero` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `livroo_id` FOREIGN KEY (`livroo_id`) REFERENCES `livro` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.livrogeneros: ~3 rows (aproximadamente)
INSERT INTO `livrogeneros` (`id`, `livroo_id`, `genero_id`) VALUES
	(1, 1, 3),
	(2, 1, 1),
	(3, 1, 3);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.redesocial
DROP TABLE IF EXISTS `redesocial`;
CREATE TABLE IF NOT EXISTS `redesocial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.redesocial: ~3 rows (aproximadamente)
INSERT INTO `redesocial` (`id`, `descr`) VALUES
	(1, 'x'),
	(2, 'Facebook'),
	(3, 'Instagram');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.seccao
DROP TABLE IF EXISTS `seccao`;
CREATE TABLE IF NOT EXISTS `seccao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.seccao: ~5 rows (aproximadamente)
INSERT INTO `seccao` (`id`, `descr`) VALUES
	(1, 'seccao1'),
	(2, 'seccao2'),
	(3, 'seccao3'),
	(4, 'seccao4'),
	(5, 'seccao5');

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.socio
DROP TABLE IF EXISTS `socio`;
CREATE TABLE IF NOT EXISTS `socio` (
  `cc` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `numSocio` int(11) DEFAULT NULL,
  `morada` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `tel` int(11) DEFAULT NULL,
  `dataNasc` date DEFAULT NULL,
  `estadoSocio_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cc`),
  KEY `estadoSocio_id` (`estadoSocio_id`),
  CONSTRAINT `estadoSocio_id` FOREIGN KEY (`estadoSocio_id`) REFERENCES `estadosocio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.socio: ~1 rows (aproximadamente)
INSERT INTO `socio` (`cc`, `nome`, `numSocio`, `morada`, `email`, `tel`, `dataNasc`, `estadoSocio_id`) VALUES
	(123456, 'nome', 1, 'evora', 'email', 123456789, '1995-09-25', 1);

-- A despejar estrutura para tabela libskilliana_patriciagois_n24.tipocol
DROP TABLE IF EXISTS `tipocol`;
CREATE TABLE IF NOT EXISTS `tipocol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela libskilliana_patriciagois_n24.tipocol: ~3 rows (aproximadamente)
INSERT INTO `tipocol` (`id`, `descr`) VALUES
	(1, 'Administrador'),
	(2, 'Bibliotecário'),
	(3, 'Armazenista');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
